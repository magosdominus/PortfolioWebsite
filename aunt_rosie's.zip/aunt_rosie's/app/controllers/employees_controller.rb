class EmployeesController < ApplicationController
layout "employees"

	def index

		if (session[:user_id] && session[:user_id] != "") 

			@user = Employee.find(session[:user_id])

		else 

			@user = Employee.new 
			flash[:danger] = "Must be logged in to access this page!"
        	redirect_to "/login"

		end 
	end

	def active_staff
		@employees = Employee.where(:discharged => 'false')
	end 

	def discharged_staff
		@employees = Employee.where(:discharged => 'true')
	end 

	def prompt
		@employee = Employee.new
	end 

	def findID
		@employee = Employee.find_by_id(employee_search_params['id'])
		if @employee
			@link = "/employees/" + @employee.id.to_s + "/edit"
			redirect_to @link
		else
			flash[:danger] = "Employee ID '" + employee_search_params['id'] + "' not found."
			redirect_to "/employees/prompt"
		end
	end 

	def edit 
		@employee = Employee.find(params[:id])
	end 

	def update
	    @employee = Employee.find(params[:id])
	    if @employee.update_attributes(employee_params)
	      flash[:success] = "Profile " + @employee.id.to_s + " updated"
	      redirect_to '/employee'
	    else
	      render 'edit'
	    end
	end 

	def new 
		@employee = Employee.new 
	end 

	def create 
		@employee = Employee.new(employee_params)
	    if @employee.save
	      flash[:info] = "Employee record created."
	      redirect_to '/employee'
	    else
	      render 'new'
	    end
	end

    def show 
 		@employee = Employee.new 
    end 

	private

	def employee_search_params
		params.require(:employee).permit(:id)
	end 

    def employee_params
      params.require(:employee).permit(:firstName, :lastName, :employeeType, :employeeAddress, :employeeCity, :employeePostalCode, :employeeUsername,
      							   :password,
                                   :password_confirmation, :discharged)
    end

end
