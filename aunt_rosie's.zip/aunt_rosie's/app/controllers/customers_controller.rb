class CustomersController < ApplicationController
layout "employees"	

	def new 
		@customer = Customer.new
	end 

	def index
		@customer = Customer.new
	end

	def prompt
		@customer = Customer.new
	end 

	def prompt_select
		@customer = Customer.new
	end

	def findIDSelect
		@customer = Customer.find_by_id(customer_search_params['id'])
		if @customer
			@link = "/customers/" + @customer.id.to_s
			redirect_to @link
		else
			flash[:danger] = "Customer ID '" + customer_search_params['id'] + "' not found."
			redirect_to "/customer/prompt_select"
		end
	end 

	def findID
		@customer = Customer.find_by_id(customer_search_params['id'])
		if @customer
			@link = "/customers/" + @customer.id.to_s + "/edit"
			redirect_to @link
		else
			flash[:danger] = "Customer ID '" + customer_search_params['id'] + "' not found."
			redirect_to "/customer/prompt_nutrition"
		end
	end 

	def create
		@customer = Customer.new(customer_params)

		if @customer.save
	  		flash[:success] = "Customer record saved."
			@link = "/employee"
			redirect_to @link		
	    else
	    	flash[:danger] = "Customer record not saved."
	    	render 'new'
	  	end	
	end 

	def update
		@customer = Customer.find_by_id(params[:id])

	 	if @customer.update(customer_params)
	 		flash[:success] = "Customer record updated."
	    	redirect_to "/employee"	
	 	else
	 		flash[:danger] = "Customer record not updated."
	    	render 'edit'
	  	end	
	end 

	def edit 
		@customer = Customer.find_by_id(params[:id])
	end 

	def delete 
	    Customer.find(params[:id]).destroy
	    flash[:success] = "Customer " + params[:id].to_s + " record deleted"
	    redirect_to "customer/customer_list"
	end

	def destroy
	    Customer.find(params[:id]).destroy
	    flash[:success] = "Customer " + params[:id].to_s + " record deleted"
	    redirect_to "customer/customer_list"
	end

	def show
		@customer = Customer.find_by_id(params[:id])
  	end

	def mailing_list
		@customers = Customer.where(:mailing_list => true)
	end 

	def customer_list
		@customers = Customer.all
	end

	private 

		def customer_search_params
			params.require(:customer).permit(:id)
		end

		def customer_params
			params.require(:customer).permit(:customer_first_name, :customer_last_name, :customer_phone_number, :customer_email, :mailing_list)
		end


end
