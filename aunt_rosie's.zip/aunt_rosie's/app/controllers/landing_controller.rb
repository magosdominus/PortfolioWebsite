class LandingController < ApplicationController

	def index

	end 


end
