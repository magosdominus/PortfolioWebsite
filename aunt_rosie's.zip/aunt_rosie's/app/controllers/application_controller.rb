class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception
  include SessionsHelper

  def current_user_articles
  	if (is_user_logged_in == true)
  		return @user = User.find(session[:user_id])
  	else 
  		@user = User.create
  		@user.id = 0
  		return @user
  	end 
  end 

  private
	    # Confirms a logged-in user.
	    def logged_in_user_articles
	      if (!session[:user_id])
	      	store_location
	        flash[:danger] = "Please log in."
	        redirect_to login_url
	      end
	    end

	    def is_user_logged_in
	    	if (session[:user_id])
	    		return true
	    	else
	    		return false
	    	end 
	    end
	    helper_method :is_user_logged_in

	    # Confirms the correct user.
	    def correct_user
	      @user = User.find(session[:user_id])
	      redirect_to(root_url) unless current_user?(@user)
	    end

	    # Confirms an admin user.
	    def admin_user
	      redirect_to(root_url) unless current_user.admin?
	    end



end
