class InvoicesController < ApplicationController
end
