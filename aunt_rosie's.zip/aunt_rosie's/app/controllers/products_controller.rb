class ProductsController < ApplicationController
layout "employees"
before_filter :set_special_layout

	def set_special_layout
	 	@url = request.path_info
	  	if @url.include?('menu')
	  		self.class.layout "application"
	  	else
	  		self.class.layout "employees"
	  	end 
	end

	def new 
		@product = Product.new
	end 

	def index
		@product = Product.new
	end

	def prompt
		@product = Product.new
	end 

	def prompt_select
		@product = Product.new
	end

	def menu
		@products = Product.all.paginate(page: params[:page])
	end 

	def findIDSelect
		@product = Product.find_by_id(product_search_params['id'])
		if @product
			@link = "/products/" + @product.id.to_s
			redirect_to @link
		else
			flash[:danger] = "Product ID '" + product_search_params['id'] + "' not found."
			redirect_to "/product/prompt_select"
		end
	end 

	def show 
		@product = Product.find_by_id(params[:id])
		@products = Product.all
		#@product_ingredients = new
	end 

	def findID
		@product = Product.find_by_id(product_search_params['id'])
		if @product
			@link = "/products/" + @product.id.to_s + "/edit"
			redirect_to @link
		else
			flash[:danger] = "Product ID '" + product_search_params['id'] + "' not found."
			redirect_to "/product/prompt_nutrition"
		end
	end 

	def edit 
		@product = Product.find_by_id(params[:id])
	end 

	def findIDNutrition
		@product = Product.find_by_id(product_search_params['id'])
		if @product
			@link = "/product/" + @product.id.to_s + "/nutrition"
			redirect_to @link
		else
			flash[:danger] = "Product ID '" + product_search_params['id'] + "' not found."
			redirect_to "/product/prompt"
		end
	end

	def prompt_nutrition
		@product = Product.new
	end 

	def nutrition
		@product = Product.find_by_id(params[:id])
	end 

	def all_products
		@products = Product.all.paginate(page: params[:page]) 
	end

	def create
		@product = Product.new(product_params)

		if @product.save
	  		flash[:success] = "Product record saved."
			@link = "/products/" + @product.id.to_s
			redirect_to @link		
	    else
	    	flash[:danger] = "Product record not saved."
	    	render 'new'
	  	end	
	end 

	def update
		@product = Product.find_by_id(params[:id])

	 	if @product.update(product_params)
	 		flash[:success] = "Product record updated."
	    	redirect_to "/employee"	
	 	else
	 		flash[:danger] = "Product record not updated."
	    	render 'edit'
	  	end	
	end 

	def delete 
	    Product.find(params[:id]).destroy
	    flash[:success] = "Product " + params[:id].to_s + " record deleted"
	    redirect_to "/product/all_products"
	end

	def destroy
	    Product.find(params[:id]).destroy
	    flash[:success] = "Product " + params[:id].to_s + " record deleted"
	    redirect_to "/product/all_products"
	end

	private 

		def product_search_params
			params.require(:product).permit(:id)
		end

		def product_params
			params.require(:product).permit(:product_name, :product_type, :unit_price, :product_size, :serving_size, :calories, :total_fat, :saturated_fat, :cholesterol, :sodium, :total_cardbohydrate, :sugars, :protein, :vitaminA, :vitaminC, :calcium, :iron, :image)
		end
end

