class ArticlesController < ApplicationController

	before_action :logged_in_user_articles, only: [:new, :create, :edit, :update, :destroy]
 	before_action :article_owner,  only: [:edit, :update, :delete, :destroy]

 	#http_basic_authenticate_with name: "dhh", password: "secret", except: [:index, :show]
	
	def index
	 	@articles = Article.all
	end

	def new
  		@article = Article.create
	end

	def edit
	  	@article = Article.find(params[:id])
	end

	def show
    	@article = Article.find(params[:id])
  	end

	def create
		@user = current_user
	  	@article = Article.new(article_params)
	 	@article.user_id = @user.id

	  	if @article.save
	  		flash[:success] = "Article created."
	    	redirect_to @article
	  	else
	    	render 'new'
	  	end
	end
	
	def update
	 	@article = Article.find(params[:id])
	 
	 	if @article.update(article_params)
	 		flash[:success] = "Article updated."
	    	redirect_to @article
	 	else
	    	render 'edit'
	  	end
	end

	def destroy
	  	@article = Article.find(params[:id])
	 	@article.destroy
	 	
	 	flash[:success] = "Article deleted."
	  	redirect_to articles_path
	end

	private
	  	def article_params
	    	params.require(:article).permit(:title, :text)
	  	end

	  	def article_owner
	  		@article = Article.find(params[:id])
	  		flash[:danger] = "Only the author may edit/delete this article." unless current_user_articles.id == @article.user_id
			redirect_to articles_path unless current_user_articles.id == @article.user_id
		end 
end
