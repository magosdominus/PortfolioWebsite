class IngredientsController < ApplicationController
layout "employees"

	def new 
		@ingredient = Ingredient.new
	end 

	def prompt
		@ingredient = Ingredient.new
	end 

	def findID
		@ingredient = Ingredient.find_by_id(ingredient_search_params['id'])
		if @ingredient
			@link = "/ingredients/" + @ingredient.id.to_s + "/edit"
			redirect_to @link
		else
			flash[:danger] = "Ingredient ID '" + ingredient_search_params['id'] + "' not found."
			redirect_to "/ingredient/prompt"
		end
	end 

	def edit 
		@ingredient = Ingredient.find_by_id(params[:id])
	end 

	def show 
		@ingredient = Ingredient.find(params[:ingredient_id])
	end 

	def inventory 
		@ingredients = Ingredient.all.paginate(page: params[:page]) 
	end 

	def create
		@ingredient = Ingredient.new(ingredient_params)

		if @ingredient.save
	  		flash[:success] = "Ingredient record saved."
	    	redirect_to "/employee"			
	    else
	    	flash[:danger] = "Ingredient record not saved."
	    	render 'new'
	  	end	
	end 

	def update
		@ingredient = Ingredient.find_by_id(params[:id])

	 	if @ingredient.update(ingredient_params)
	 		flash[:success] = "Ingredient record updated."
	    	redirect_to "/employee"	
	 	else
	 		flash[:danger] = "Ingredient record not updated."
	    	render 'edit'
	  	end		
	end 

	def delete 
	    Ingredient.find(params[:id]).destroy
	    flash[:success] = "Ingredient " + params[:id].to_s + " record deleted"
	    redirect_to "/ingredient/inventory"
	end

	def destroy
	    Ingredient.find(params[:id]).destroy
	    flash[:success] = "Ingredient " + params[:id].to_s + " record deleted"
	    redirect_to "/ingredient/inventory"
	end

	private 

		def ingredient_search_params
			params.require(:ingredient).permit(:id)
		end

		def ingredient_params
			params.require(:ingredient).permit(:ingredient_name, :quantity_in_storage)
		end
end
