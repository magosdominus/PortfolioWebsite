class SessionsController < ApplicationController

  def new
  end

  def create
    @user = Employee.find_by(employeeUsername: params[:session][:employeeUsername])
    
    if @user && @user.authenticate(params[:session][:employeePassword])
      log_in @user
      flash.now[:success] = "You have successfully logged in."
      redirect_to '/employees'
    else
      flash[:danger] = 'Invalid email/password combination'
      render 'new'
    end
  end

  def destroy
    log_out if logged_in?
    flash[:success] = "You have successfully logged out."
    redirect_to root_url
  end

  private

  def login_params 
    params.require(:session).permit(:employeeUsername)
  end 
end