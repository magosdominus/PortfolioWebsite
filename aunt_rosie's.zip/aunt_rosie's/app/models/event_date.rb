class EventDate < ApplicationRecord
end
