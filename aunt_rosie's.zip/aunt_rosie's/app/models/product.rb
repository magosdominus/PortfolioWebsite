class Product < ApplicationRecord
	validates :product_name, presence: true, length: { maximum: 50 }
	validates :product_type, presence: true, length: { maximum: 30 }
	
	validates :unit_price, presence: true, :format => { :with => /\A\d+(?:\.\d{0,2})?\z/ }, :numericality => {:greater_than => 0}
	validates :product_size, presence: true, :format => { :with => /\A\d+(?:\.\d{0,2})?\z/ }, :numericality => {:greater_than => 0}
	validates :serving_size, presence: true, :format => { :with => /\A\d+(?:\.\d{0,2})?\z/ }, :numericality => {:greater_than => 0}
	validates :vitaminA, presence: true, :format => { :with => /\A\d+(?:\.\d{0,2})?\z/ }
	validates :vitaminC, presence: true, :format => { :with => /\A\d+(?:\.\d{0,2})?\z/ }
	validates :calcium, presence: true, :format => { :with => /\A\d+(?:\.\d{0,2})?\z/ }
	validates :iron, presence: true, :format => { :with => /\A\d+(?:\.\d{0,2})?\z/ }

	validates :calories, presence: true, :numericality => {:less_than => 10000}
	validates :total_fat, presence: true, :numericality => {:less_than => 100}
	validates :saturated_fat, presence: true, :numericality => {:less_than => 100}
	validates :cholesterol, presence: true, :numericality => {:less_than => 100}
	validates :sodium, presence: true, :numericality => {:less_than => 100}
	validates :total_cardbohydrate, presence: true, :numericality => {:less_than => 100}
	validates :sugars, presence: true, :numericality => {:less_than => 100}
	validates :protein, presence: true, :numericality => {:less_than => 100}

	has_attached_file :product_image, :styles => { :thumb => "50x50>", :large => "1000x1000>", :medium => "200x200>" },
                  :url  => "/assets/products/:id/:style/:basename.:extension",
                  :path => ":rails_root/public/assets/products/:id/:style/:basename.:extension"
	
	#validates_attachment_presence :product_image
	validates_attachment_size :product_image, :less_than => 5.megabytes
	validates_attachment_content_type :product_image, :content_type => ['image/jpeg', 'image/png', 'image/jpg']

	has_many :productIngredients
	has_many :ingredients, :through => :productIngredients

end
