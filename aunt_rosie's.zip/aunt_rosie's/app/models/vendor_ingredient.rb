class VendorIngredient < ApplicationRecord
end
