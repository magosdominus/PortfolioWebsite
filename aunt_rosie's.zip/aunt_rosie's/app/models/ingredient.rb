class Ingredient < ApplicationRecord
	validates :ingredient_name,  presence: true, length: { maximum: 50 }
	validates :quantity_in_storage,  presence: true, length: { maximum: 4 }, :format => { :with => /\A\d+(?:\.\d{0,2})?\z/ }, :numericality => {:less_than => 10000000}

	has_many :productIngredients
	has_many :products, :through => :productIngredients
end
