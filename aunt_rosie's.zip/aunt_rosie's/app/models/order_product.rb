class OrderProduct < ApplicationRecord
end
