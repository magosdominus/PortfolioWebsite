class BulkOrder < ApplicationRecord
end
