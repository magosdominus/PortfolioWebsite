class Employee < ApplicationRecord
  validates :firstName,  presence: true, length: { maximum: 50 }
  validates :lastName,  presence: true, length: { maximum: 50 }
  validates :employeeType, presence: true
  validates :discharged, presence: true 
  validates :employeeUsername, presence: true, length: { maximum: 20 },
                    uniqueness: { case_sensitive: false }
  has_secure_password
  validates :password, presence: true, length: { minimum: 6 }, allow_nil: true

  # Returns the hash digest of the given string.
  def Employee.digest(string)
    cost = ActiveModel::SecurePassword.min_cost ? BCrypt::Engine::MIN_COST :
                                                  BCrypt::Engine.cost
    BCrypt::Password.create(string, cost: cost)
  end

  def correctPassword(employeePassword)
  	if (@employeePassword = self.password_digest)
  		return true
	else
	  	return false
	end 
  end

  # Returns a random token.
  def Employee.new_token
    SecureRandom.urlsafe_base64
  end

  # Returns true if the given token matches the digest.
  def authenticated?(attribute, token)
    digest = send("#{attribute}_digest")
    return false if digest.nil?
    BCrypt::Password.new(digest).is_password?(token)
  end

  private
end
