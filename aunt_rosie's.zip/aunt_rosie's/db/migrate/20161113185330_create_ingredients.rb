class CreateIngredients < ActiveRecord::Migration[5.0]
  def change
    create_table :ingredients do |t|
    	drop_table(:ingredients, if_exists: true)
        t.string :ingredient_name, limit: 50
        t.decimal :quantity_in_storage, limit: 4
    end
  end
end
