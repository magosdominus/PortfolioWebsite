class CreateEmployees < ActiveRecord::Migration[5.0]
  def change
    drop_table(:employees, if_exists: true)
    create_table :employees do |t|

      t.string :firstName
      t.string :lastName
      t.string :employeeType
      t.string :employeeAddress
      t.string :employeeCity
      t.string :employeePostalCode
      t.string :employeeUsername
      t.string :password_digest
      t.string :discharged

      t.timestamps
    end
  end
end
