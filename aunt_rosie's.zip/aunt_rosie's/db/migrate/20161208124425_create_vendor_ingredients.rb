class CreateVendorIngredients < ActiveRecord::Migration[5.0]
  def change
  	drop_table(:vendor_ingredients, if_exists: true)
    create_table :vendor_ingredients do |t|

      t.references :vendor, foreign_key: true
      t.decimal :unit_price

    end
  end
end
