class CreateOrderProducts < ActiveRecord::Migration[5.0]
  def change
  	drop_table(:order_products, if_exists: true)
    create_table :order_products do |t|

      t.references :product, foreign_key: true
      t.integer :quantity

    end
  end
end
