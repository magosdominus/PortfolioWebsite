class CreateCustomers < ActiveRecord::Migration[5.0]
  def change
    create_table :customers do |t|
    	drop_table(:customers, if_exists: true)
        t.string :customer_first_name
        t.string :customer_last_name
        t.string :customer_phone_number
        t.string :customer_email
        t.boolean :mailing_list
    end
  end
end
