class CreateProductIngredients < ActiveRecord::Migration[5.0]
  def change
    create_table :product_ingredients do |t|
      drop_table(:product_ingredients, if_exists: true)

      t.references :product, index: true
      t.references :ingredient, index: true
      t.decimal :quantity
    end
  end
end
