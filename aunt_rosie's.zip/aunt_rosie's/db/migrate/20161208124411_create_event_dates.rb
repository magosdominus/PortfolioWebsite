class CreateEventDates < ActiveRecord::Migration[5.0]
  def change
  	drop_table(:event_dates, if_exists: true)
    create_table :event_dates do |t|

      t.datetime :event_date
      t.references :event, foreign_key: true

    end
  end
end
