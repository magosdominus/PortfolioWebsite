class CreateEvents < ActiveRecord::Migration[5.0]
  def change
  	drop_table(:events, if_exists: true)
    create_table :events do |t|

    	t.string :event_name
    	t.string :event_address
    	t.string :event_city
    	t.string :event_postal_code

    end
  end
end
