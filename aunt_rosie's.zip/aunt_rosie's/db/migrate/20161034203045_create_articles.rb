class CreateArticles < ActiveRecord::Migration[5.0]
  def change
  	drop_table(:articles, if_exists: true)
    create_table :articles do |t|
      t.string :title
      t.text :text

      t.references :user, foreign_key: true

      t.timestamps
    end
  end
end
