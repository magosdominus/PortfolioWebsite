class CreateProducts < ActiveRecord::Migration[5.0]
  def change
    create_table :products do |t|
      drop_table(:products, if_exists: true)

      t.string :product_name, limit:50
      t.string :product_type, limit:30
      t.decimal :unit_price
      t.decimal :product_size
      t.decimal :serving_size
      t.integer :calories
      t.integer :total_fat 
      t.integer :saturated_fat
      t.integer :cholesterol
      t.integer :sodium
      t.integer :total_cardbohydrate
      t.integer :sugars
      t.integer :protein
      t.decimal :vitaminA
      t.decimal :vitaminC
      t.decimal :calcium
      t.decimal :iron
    end
  end
end
