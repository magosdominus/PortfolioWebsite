class CreateVendors < ActiveRecord::Migration[5.0]
  def change
  	drop_table(:vendors, if_exists: true)
    create_table :vendors do |t|

    	t.string :vendor_name
    	t.string :vendor_address
    	t.string :vendor_city
    	t.string :vendor_postal_code
    	t.string :vendor_phone_number 
    end
  end
end

