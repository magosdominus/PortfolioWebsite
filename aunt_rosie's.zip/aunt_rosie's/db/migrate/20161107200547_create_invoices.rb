class CreateInvoices < ActiveRecord::Migration[5.0]
  def change
  	drop_table(:invoices, if_exists: true)
    create_table :invoices do |t|
      
        t.references :customer, foreign_key: true
   		t.datetime :date_of_invoice

    end
  end
end
