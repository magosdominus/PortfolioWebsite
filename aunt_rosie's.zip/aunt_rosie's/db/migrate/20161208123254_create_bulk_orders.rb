class CreateBulkOrders < ActiveRecord::Migration[5.0]
  def change
  	drop_table(:bulk_orders, if_exists: true)
    create_table :bulk_orders do |t|
      
        t.references :customer, foreign_key: true
   		t.string :delivery_address
   		t.string :delivery_city
   		t.string :delivery_postal_code
   		t.datetime :date_of_order
   		t.datetime :delivery_date
   		t.boolean :order_fulfilled

    end
  end
end
