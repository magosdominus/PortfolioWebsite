require 'test_helper'

class BulkOrderTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
