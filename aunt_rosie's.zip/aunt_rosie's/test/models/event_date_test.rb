require 'test_helper'

class EventDateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
