require 'test_helper'

class ProductIngredientTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
