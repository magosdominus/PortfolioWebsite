Rails.application.routes.draw do
  get 'password_resets/new'

  get 'password_resets/edit'

  get 'sessions/new'

  get 'users/new'

  get 'welcome/index'

  root 'welcome#index'

  get '/menu', to: 'products#menu'

  get '/', to: 'welcome#index'

  get '/employees/discharged_staff', to: 'employees#discharged_staff'
  get '/employees/active_staff', to: 'employees#active_staff'
  #resources :articles do
  #resources :comments
  #end
 
	#root 'static_pages#home'
	#get  '/help',    to: 'static_pages#help'
	#get  '/about',   to: 'static_pages#about'
	#get  '/contact', to: 'static_pages#contact'
	#get  '/signup',  to: 'users#new'
	#post '/signup',  to: 'users#create'
	get    '/login',   to: 'sessions#new'
	get    '/logout',   to: 'sessions#destroy'
	post   '/login',   to: 'sessions#create'
	delete '/logout',  to: 'sessions#destroy'
	get    '/delete',   to: 'sessions#destroy'
	
	
	resources :customers
	get '/customer/mailing_list', to: 'customers#mailing_list'
	get '/customer/customer_list', to: 'customers#customer_list'

	get '/customer/new', to: 'customers#new'
	
	get '/customer/prompt', to: 'customers#prompt'
	post '/customer/prompt', 	to: 'customers#findID'
	get '/customer/prompt_select', to: 'customers#prompt_select'
	post '/customer/prompt_select', 	to: 'customers#findIDSelect'

	#get '/customer/all_customers', to: 'customers#destroy'
	#post 'customers/:id', to: 'customers#delete'
	delete 'customer/:id', to: 'customers#delete'

	resources :products
	get '/product/new',	to: 'products#new'
	get '/product/prompt',	to: 'products#prompt'
	post '/product/prompt', 	to: 'products#findID'
	get '/product/all_products', to: 'products#all_products'

	get '/product/prompt_select', to: 'products#prompt_select'
	post '/product/prompt_select', to: 'products#findIDSelect'

	get '/product/prompt_nutrition', to: 'products#prompt_nutrition'
	post '/product/prompt_nutrition', to: 'products#findIDNutrition'
	get '/product/:id/nutrition', to: 'products#nutrition'

	post 'products/:id', to: 'products#delete'
	delete 'products/:id', to: 'products#delete'

	get '/product/:id', to: 'products#show'
	
	get '/employees/prompt', to: 'employees#prompt'
	post '/employees/prompt', 	to: 'employees#findID'

	resources :employees
	get '/employee', to: 'employees#index'

	get '/about', to: 'welcome#about'
	get '/contact', to: 'welcome#contact'




	#resources :users
	#resources :account_activations, only: [:edit]
	resources :password_resets,     only: [:new, :create, :edit, :update]
	
	resources :ingredients
	get  '/ingredient/new', 	to: 'ingredients#new'
	post '/ingredient/new', 	to: 'ingredients#create'
	post '/ingredient/prompt', 	to: 'ingredients#findID'
	get  '/ingredient/prompt', 	to: 'ingredients#prompt'
	get  '/ingredient/inventory', 	to: 'ingredients#inventory'

  #get '/logout', to: 'welcome#logout' 


  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
